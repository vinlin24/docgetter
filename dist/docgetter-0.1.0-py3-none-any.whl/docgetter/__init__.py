"""__init__.py

Initialize package namespace.
"""

__author__ = "Vincent Lin"
__version__ = "0.1.0"
